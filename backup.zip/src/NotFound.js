
export function NotFound() {
    return (
        <>
            <h1>NotFound 404</h1>
        </>
    )
}
