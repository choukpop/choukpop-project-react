export const elements = {
  geo: {
    id: 'geo',
    name: 'Geo',
    simpleName: 'Stone',
  },
  anemo: {
    id: 'anemo',
    name: 'Anemo',
    simpleName: 'Wind',
  },
  pyro: {
    id: 'pyro',
    name: 'Pyro',
    simpleName: 'Fire',
  },
  hydro: {
    id: 'hydro',
    name: 'Hydro',
    simpleName: 'Water',
  },
  electro: {
    id: 'electro',
    name: 'Electro',
    simpleName: 'Electro',
  },
  dendro: {
    id: 'dendro',
    name: 'Dendro',
    simpleName: 'Grass',
  },
  cryo: {
    id: 'cryo',
    name: 'Cryo',
    simpleName: 'Ice',
  },
};
